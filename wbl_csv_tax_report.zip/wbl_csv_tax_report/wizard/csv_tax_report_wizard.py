# -*- coding: utf-8 -*-
#
#################################################################################
# Author      : Weblytic Labs Pvt. Ltd. (<https://store.weblyticlabs.com/>)
# Copyright(c): 2023-Present Weblytic Labs Pvt. Ltd.
# All Rights Reserved.
#
#
# This program is copyright property of the author mentioned above.
# You can`t redistribute it and/or modify it.
##################################################################################

import base64
import csv
from odoo import models, fields
from io import StringIO


class CSVTaxReportWizard(models.Model):
    _name = 'csv.tax.report.wizard'
    _description = 'CSV Tax Report Wizard'

    start_date = fields.Date(string='Start Date')
    end_date = fields.Date(string='End Date')

    def csv_file_export(self):

        domain = [
            ('move_type', 'in', ['out_invoice', 'out_refund']),
            ('state', '=', 'posted'),
        ]

        if self.start_date:
            domain.append(('invoice_date', '>=', self.start_date))
        if self.end_date:
            domain.append(('invoice_date', '<=', self.end_date))

        invoices = self.env['account.move'].search(domain)

        # Create CSV
        csv_buffer = StringIO()
        writer = csv.writer(csv_buffer)
        writer.writerow(
            ['Gesamt', 'Ein-/Ausgangsrechnungsdatum', 'Kunde/USt-IdNr.', 'Steuersatz', 'Steuerlicher Ländercode',
             'Lieferadresse/Steuerliche Ländercodes',
             'Versender Ländercode', 'Rechnungsnummer', 'Externe Transaktionsnummer', 'Zahlungsreferenz',
             'Transaktionen/Zahlungsmethode',
             'Rechnungszeilen/Währung',
             ])

        for invoice in invoices:
            tax_names = []
            tax_country_names = []
            for line in invoice.invoice_line_ids:
                for tax in line.tax_ids:
                    tax_names.append(str(tax.amount))
                    tax_country_names.append(tax.country_id.code or 'N/A')

            payments = invoice._get_reconciled_payments()
            payment_refs = ", ".join(payments.mapped('name'))
            payment_methods = ", ".join(payments.mapped('payment_method_id.name'))

            writer.writerow([
                invoice.amount_total,
                invoice.invoice_date.strftime('%Y-%m-%d') if invoice.invoice_date else '',
                invoice.partner_id.vat or '',
                ", ".join(tax_names),
                ", ".join(tax_country_names),
                invoice.partner_id.country_id.code or '',
                "DE",
                invoice.name,
                '',
                payment_refs or '',
                payment_methods,
                invoice.currency_id.name,
            ])

        csv_content = csv_buffer.getvalue()
        csv_buffer.close()

        csv_base64 = base64.b64encode(csv_content.encode('utf-8'))

        attachment = self.env['ir.attachment'].create({
            'name': 'invoice_export.csv',
            'type': 'binary',
            'datas': csv_base64,
            'mimetype': 'text/csv',
            'res_model': self._name,
            'res_id': self.id,
        })

        download_url = '/web/content/%s?download=true' % attachment.id
        return {
            'type': 'ir.actions.act_url',
            'url': download_url,
            'target': 'self',
        }
