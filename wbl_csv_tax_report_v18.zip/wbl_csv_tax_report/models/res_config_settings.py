# -*- coding: utf-8 -*-
#
#################################################################################
# Author      : Weblytic Labs Pvt. Ltd. (<https://store.weblyticlabs.com/>)
# Copyright(c): 2023-Present Weblytic Labs Pvt. Ltd.
# All Rights Reserved.
#
#
# This program is copyright property of the author mentioned above.
# You can`t redistribute it and/or modify it.
##################################################################################

import logging
from datetime import datetime
from odoo import models, api, fields

_logger = logging.getLogger(__name__)

class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    enable_csv_tax_report_mail = fields.Boolean(string="Enable CSV Tax Report Mail")
    add_customer_email = fields.Many2many('csv.mail', string='Enter Customer Email')
    nextcall_datetime = fields.Selection(
        selection=[(str(i), f"{i}") for i in range(1, 32)],
        help="An email will be sent every month on the selected day.")

    @api.model
    def set_values(self):
        super(ResConfigSettings, self).set_values()
        param = self.env['ir.config_parameter'].sudo()
        email_ids = self.add_customer_email.ids or []

        param.set_param('res.config.settings.enable_csv_tax_report_mail', str(self.enable_csv_tax_report_mail))
        param.set_param('res.config.settings.nextcall_datetime', self.nextcall_datetime)
        param.set_param('res.config.settings.add_customer_email', ','.join(map(str, email_ids)))

        cron = self.env.ref('wbl_csv_tax_report.ir_cron_invoice_export_email', raise_if_not_found=False)
        if cron:
            values = {'active': self.enable_csv_tax_report_mail}
            if self.nextcall_datetime:
                try:
                    day = int(self.nextcall_datetime)
                    today = fields.Date.today()
                    year = today.year
                    month = today.month
                    from calendar import monthrange
                    last_day = monthrange(year, month)[1]
                    day = min(day, last_day)
                    nextcall_dt = datetime(year, month, day, 0, 0, 0)
                    values['nextcall'] = nextcall_dt.strftime('%Y-%m-%d %H:%M:%S')
                except Exception as e:
                    _logger.error(f"Invalid day format for nextcall: {e}")
            cron.sudo().write(values)

        _logger.info("set_values executed")
        return True

    def get_values(self):
        res = super().get_values()
        param = self.env['ir.config_parameter'].sudo()

        email_id_str = param.get_param('res.config.settings.add_customer_email')
        email_ids = []
        if email_id_str:
            try:
                email_ids = list(map(int, email_id_str.split(',')))
            except Exception as e:
                _logger.warning("Failed to parse email ID list: %s", e)

        res.update(
            enable_csv_tax_report_mail=param.get_param('res.config.settings.enable_csv_tax_report_mail') == 'True',
            nextcall_datetime=param.get_param('res.config.settings.nextcall_datetime'),
            add_customer_email=[(6, 0, email_ids)],
        )

        _logger.info("get_values executed:", res)
        return res

