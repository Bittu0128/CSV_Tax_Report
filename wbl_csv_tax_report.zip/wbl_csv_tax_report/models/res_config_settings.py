from datetime import datetime
from odoo import models, api, fields
from dateutil import parser


class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    enable_csv_tax_report_mail = fields.Boolean(string="Enable CSV Tax Report Mail")
    nextcall_datetime = fields.Date(string="Select Date for Email Invoice")
    add_customer_email = fields.Char(string='Enter Customer Email')

    @api.model
    def set_values(self):
        super(ResConfigSettings, self).set_values()
        param = self.env['ir.config_parameter'].sudo()

        param.set_param('res.config.settings.enable_csv_tax_report_mail', str(self.enable_csv_tax_report_mail))
        param.set_param('res.config.settings.nextcall_datetime', self.nextcall_datetime)
        param.set_param('res.config.settings.add_customer_email', self.add_customer_email)

        cron = self.env.ref('wbl_csv_tax_report.ir_cron_invoice_export_email', raise_if_not_found=False)
        if cron:
            values = {'active': self.enable_csv_tax_report_mail}
            if self.nextcall_datetime:
                values['nextcall'] = self.nextcall_datetime
            cron.sudo().write(values)

        # print("✅ set_values executed")
        return True

    def get_values(self):
        res = super(ResConfigSettings, self).get_values()
        param = self.env['ir.config_parameter'].sudo()

        # Convert string to datetime (if set)
        nextcall_str = param.get_param('res.config.settings.nextcall_datetime')
        nextcall_dt = parser.parse(nextcall_str) if nextcall_str else False
        res.update(
            enable_csv_tax_report_mail=param.get_param('res.config.settings.enable_csv_tax_report_mail'),
            nextcall_datetime=nextcall_dt,
            add_customer_email=param.get_param('res.config.settings.add_customer_email'),
        )
        print("get", res)
        return res
