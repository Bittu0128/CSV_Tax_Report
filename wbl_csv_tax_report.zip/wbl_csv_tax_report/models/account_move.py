from odoo import models, api, fields


class AccountMove(models.Model):
    _inherit = 'account.move'

    def export_and_email_invoices_csv(self):
        # config = self.env['ir.config_parameter'].sudo()
        # email_activation = config.get_param('res.config.settings.enable_csv_tax_report_mail')
        print("djhbfdkga")
