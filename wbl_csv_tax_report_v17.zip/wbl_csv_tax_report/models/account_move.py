# -*- coding: utf-8 -*-
#
#################################################################################
# Author      : Weblytic Labs Pvt. Ltd. (<https://store.weblyticlabs.com/>)
# Copyright(c): 2023-Present Weblytic Labs Pvt. Ltd.
# All Rights Reserved.
#
#
# This program is copyright property of the author mentioned above.
# You can`t redistribute it and/or modify it.
##################################################################################

from odoo import models, fields
from datetime import timedelta
import logging
import base64
import csv
from io import StringIO
from babel.dates import format_date

_logger = logging.getLogger(__name__)


class AccountMove(models.Model):
    _inherit = 'account.move'

    def export_and_email_invoices_csv(self):
        config = self.env['ir.config_parameter'].sudo()
        nextcall_str = config.get_param('res.config.settings.nextcall_datetime')
        email_ids_str = config.get_param('res.config.settings.add_customer_email')

        if not nextcall_str or not email_ids_str:
            _logger.warning("Missing nextcall date or customer email configuration.")
            return

        try:
            scheduled_day = int(nextcall_str)
        except Exception as e:
            _logger.error(f"Invalid day in nextcall_datetime: {e}")
            return

        today = fields.Date.today()
        if today.day != scheduled_day:
            _logger.info(f"⏩ Skipping cron — today is {today.day}, scheduled for {scheduled_day}")
            return

        # Step 1: Get email addresses from csv.mail model
        try:
            email_ids = list(map(int, email_ids_str.split(','))) if email_ids_str else []
            csv_mails = self.env['csv.mail'].browse(email_ids)
            email_to_list = [rec.name for rec in csv_mails if rec.name]
        except Exception as e:
            _logger.error(f"Error parsing customer emails: {e}")
            return

        if not email_to_list:
            _logger.warning("No valid recipient emails found.")
            return

        # Step 2: Mail template
        template = self.env.ref('wbl_csv_tax_report.mail_template_Csc_Tax_Report', raise_if_not_found=False)
        if not template:
            _logger.warning("Email template not found.")
            return

        try:
            # Step 3: Fetch invoice records
            start_date = today - timedelta(days=30)
            domain = [
                ('move_type', 'in', ['out_invoice', 'out_refund']),
                ('state', '=', 'posted'),
                ('invoice_date', '>=', start_date),
                ('invoice_date', '<=', today),
            ]
            invoices = self.search(domain)

            if not invoices:
                _logger.info("No invoices found in the last 30 days.")
                return

            # Step 4: Generate CSV content
            csv_buffer = StringIO()
            writer = csv.writer(csv_buffer)
            writer.writerow([
                'Gesamt', 'Ein-/Ausgangsrechnungsdatum', 'Kunde/USt-IdNr.', 'Steuersatz',
                'Steuerlicher Ländercode', 'Lieferadresse/Steuerliche Ländercodes',
                'Versender Ländercode', 'Rechnungsnummer', 'Externe Transaktionsnummer',
                'Zahlungsreferenz', 'Transaktionen/Zahlungsmethode', 'Rechnungszeilen/Währung'
            ])

            for invoice in invoices:
                tax_names = []

                for line in invoice.invoice_line_ids:
                    for tax in line.tax_ids:
                        tax_names.append(str(tax.amount))

                payments = invoice._get_reconciled_payments()
                payment_refs = ", ".join(payments.mapped('name'))
                payment_methods = ", ".join(payments.mapped('payment_method_id.name'))

                writer.writerow([
                    invoice.amount_total,
                    invoice.invoice_date.strftime('%Y-%m-%d') if invoice.invoice_date else '',
                    invoice.partner_id.vat or '',
                    ", ".join(tax_names),
                    invoice.partner_id.country_id.code or '',
                    invoice.partner_id.country_id.code or '',
                    "DE",
                    invoice.name,
                    '',
                    payment_refs or '',
                    payment_methods,
                    invoice.currency_id.name,
                ])

            csv_content = csv_buffer.getvalue()
            csv_buffer.close()
            csv_base64 = base64.b64encode(csv_content.encode('utf-8'))

            # Step 5: Create attachment
            attachment = self.env['ir.attachment'].create({
                'name': f'Invoice_Export_{today}.csv',
                'type': 'binary',
                'datas': csv_base64,
                'mimetype': 'text/csv',
                'res_model': 'account.move',
                'res_id': invoices[0].id,
            })

            # Step 6: Send mail individually to each recipient
            for recipient_email in email_to_list:
                today = fields.Date.today()
                email_start_date = today - timedelta(days=30)
                email_end_date = today
                admin_user = self.env.ref('base.user_admin', raise_if_not_found=False)
                admin_email = admin_user.email if admin_user else False
                try:
                    mail_id = template.with_context({
                        'start_date': email_start_date.strftime('%d-%m-%Y'),
                        'end_date': email_end_date.strftime('%d-%m-%Y'),
                        'month': format_date(email_start_date, format='MMMM', locale='en'),
                        'year': email_start_date.year,
                    }).sudo().send_mail(
                        invoices[0].id,
                        email_values={
                            'email_to': recipient_email,
                            'email_from': admin_email,
                        },
                        force_send=False
                    )
                    _logger.info("Sending mail with date range: %s to %s", email_start_date, email_end_date)

                    if mail_id and attachment:
                        mail_record = self.env['mail.mail'].browse(mail_id)
                        mail_record.write({
                            'attachment_ids': [(4, attachment.id)]
                        })
                        mail_record.send()
                        _logger.info("Invoice CSV sent to: %s", recipient_email)
                except Exception as e:
                    _logger.error(f"Failed to send email to {recipient_email}: {e}")

        except Exception as e:
            _logger.error(f"General error during export/email process: {e}")
