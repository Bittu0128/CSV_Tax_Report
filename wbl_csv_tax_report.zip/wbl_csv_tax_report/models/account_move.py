from logging import config

from odoo import models, fields, api
import logging
import base64
import csv
from io import StringIO
from datetime import datetime

_logger = logging.getLogger(__name__)


class AccountMove(models.Model):
    _inherit = 'account.move'

    def export_and_email_invoices_csv(self):
        config = self.env['ir.config_parameter'].sudo()
        nextcall_str = config.get_param('res.config.settings.nextcall_datetime')
        email_to = config.get_param('res.config.settings.add_customer_email')

        if not nextcall_str or not email_to:
            return

        try:
            run_date = datetime.strptime(nextcall_str, '%Y-%m-%d')
            scheduled_day = run_date.day
            print(scheduled_day)
        except Exception as e:
            _logger.error(f"Invalid date format in nextcall_datetime: {e}")
            return

        today = fields.Date.today()
        print((today))
        if today.day != scheduled_day:
            _logger.info(f"Skipped cron — today is {today.day}, scheduled for {scheduled_day}")
            return

        # Fetch the mail template
        template = self.env.ref('wbl_csv_tax_report.mail_template_Csc_Tax_Report', raise_if_not_found=False)

        if not template:
            _logger.warning("❌ Email template not found.")
            return

        try:
            # Get admin email or any fallback recipient
            admin_user = self.env.ref('base.user_admin', raise_if_not_found=False)
            admin_email = admin_user.email if admin_user else False

            if not admin_email:
                _logger.warning("❌ Admin email is missing.")
                return

            # STEP 1: Filter invoices for today
            today = fields.Date.today()
            domain = [
                ('move_type', 'in', ['out_invoice', 'out_refund']),
                ('state', '=', 'posted'),
            ]
            invoices = self.search(domain)

            if not invoices:
                _logger.info("✅ No invoices to include in CSV today.")
                return

            # STEP 2: Generate CSV content
            csv_buffer = StringIO()
            writer = csv.writer(csv_buffer)
            writer.writerow(
                ['Gesamt', 'Ein-/Ausgangsrechnungsdatum', 'Kunde/USt-IdNr.', 'Steuersatz', 'Steuerlicher Ländercode',
                 'Lieferadresse/Steuerliche Ländercodes',
                 'Versender Ländercode', 'Rechnungsnummer', 'Externe Transaktionsnummer', 'Zahlungsreferenz',
                 'Transaktionen/Zahlungsmethode',
                 'Rechnungszeilen/Währung',
                 ])

            for invoice in invoices:
                tax_names = []
                tax_country_names = []

                for line in invoice.invoice_line_ids:
                    for tax in line.tax_ids:
                        tax_names.append(str(tax.amount))
                        tax_country_names.append(tax.country_id.code or 'N/A')

                payments = invoice._get_reconciled_payments()
                payment_refs = ", ".join(payments.mapped('name'))
                payment_methods = ", ".join(payments.mapped('payment_method_id.name'))

                writer.writerow([
                    invoice.amount_total,
                    invoice.invoice_date.strftime('%Y-%m-%d') if invoice.invoice_date else '',
                    invoice.partner_id.vat or '',
                    ", ".join(tax_names),
                    ", ".join(tax_country_names),
                    invoice.partner_id.country_id.code or '',
                    "DE",
                    invoice.name,
                    '',
                    payment_refs or '',
                    payment_methods,
                    invoice.currency_id.name,
                    # invoice.partner_id.name or '', # For Customer Name
                ])

            csv_content = csv_buffer.getvalue()
            csv_buffer.close()

            csv_base64 = base64.b64encode(csv_content.encode('utf-8'))

            # STEP 3: Create CSV attachment
            attachment = self.env['ir.attachment'].create({
                'name': f'Invoice_Export_{today}.csv',
                'type': 'binary',
                'datas': csv_base64,
                'mimetype': 'text/csv',
                'res_model': 'account.move',
                'res_id': invoices[0].id,
            })

            # STEP 4: Prepare and send the email
            email_to = config.get_param('res.config.settings.add_customer_email')

            email_values = {
                'email_to': email_to,
                'email_from': 'wblintern4@gmail.com',
            }
            print(email_values)

            # Generate the mail (do not send yet)
            mail_id = template.sudo().send_mail(
                invoices[0].id,
                email_values=email_values,
                force_send=False
            )

            # Manually attach CSV and then send mail
            if mail_id and attachment:
                mail_record = self.env['mail.mail'].browse(mail_id)
                mail_record.write({
                    'attachment_ids': [(4, attachment.id)]
                })
                mail_record.send()

            _logger.info("✅ Invoice CSV email with attachment sent successfully.")

        except Exception as e:
            _logger.error(f"❌ Error sending invoice CSV email: {e}")
