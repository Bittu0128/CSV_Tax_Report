from odoo import models, api, fields


class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    enable_csv_tax_report_mail = fields.Boolean(string="Enable CSV Tax Report Mail")

    @api.model
    def set_values(self):
        res = super(ResConfigSettings, self).set_values()
        self.env['ir.config_parameter'].sudo().set_param('res.config.settings.enable_csv_tax_report_mail',
                                                         self.enable_csv_tax_report_mail)
        return res

    def get_values(self):
        res = super(ResConfigSettings, self).get_values()
        ir_config_parameter_sudo = self.env['ir.config_parameter'].sudo()
        res.update(
            enable_csv_tax_report_mail=ir_config_parameter_sudo.get_param('res.config.settings.enable_csv_tax_report_mail'),
        )
        return res
