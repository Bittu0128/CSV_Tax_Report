from odoo import models

class AccountMove(models.Model):
    _inherit = 'sale.order'