from odoo import models, fields, _
import base64
import csv
from io import StringIO


class BluesnapRefundAmountWizard(models.TransientModel):
    _name = 'csv.tax.report.wizard'
    _description = 'CSV Tax Report Wizard'

    start_date = fields.Date(string='Start Date')
    end_date = fields.Date(string='End Date')

    def csv_file_export(self):
        print("Wizard start_date:", self.start_date)
        print("Wizard end_date:", self.end_date)

        invoices = self.env['account.move'].search([
            ('invoice_date', '>=', self.start_date),
            ('invoice_date', '<=', self.end_date),
            ('move_type', 'in', ['out_invoice', 'out_refund']),
            ('state', '=', 'posted'),
        ])

        # Create CSV
        csv_buffer = StringIO()
        writer = csv.writer(csv_buffer)
        writer.writerow(['Invoice Number', 'Customer', 'Invoice Date', 'Total Amount', 'Sender Country Code',
                         'Invoice Lines/Currency', 'Tax Rate', 'Payment Ref.','Payment Method'])

        for invoice in invoices:
            # For Handel, Multple Tax (Bhot sare tax apply ho shkte ha)
            tax_names = []
            for line in invoice.invoice_line_ids:
                for tax in line.tax_ids:
                    tax_names.append(str(tax.amount))   # Yrr muje amount chayye bss isliye kiya.

                # Get reconciled payments
            payments = invoice._get_reconciled_payments()
            payment_refs = ", ".join(payments.mapped('name'))
            payment_methods = ", ".join(payments.mapped('payment_method_id.name'))

            writer.writerow([
                invoice.name,
                invoice.partner_id.name or '',
                invoice.invoice_date.strftime('%Y-%m-%d') if invoice.invoice_date else '',
                invoice.amount_total,
                "DE",
                invoice.currency_id.name,
                ", ".join(tax_names),
                payment_refs or '',
                payment_methods,
            ])

        csv_content = csv_buffer.getvalue()
        csv_buffer.close()

        # Encode as base64
        csv_base64 = base64.b64encode(csv_content.encode('utf-8'))

        # Create attachment
        attachment = self.env['ir.attachment'].create({
            'name': 'invoice_export.csv',
            'type': 'binary',
            'datas': csv_base64,
            'mimetype': 'text/csv',
            'res_model': self._name,
            'res_id': self.id,
        })

        download_url = '/web/content/%s?download=true' % attachment.id

        return {
            'type': 'ir.actions.act_url',
            'url': download_url,
            'target': 'self',
        }
