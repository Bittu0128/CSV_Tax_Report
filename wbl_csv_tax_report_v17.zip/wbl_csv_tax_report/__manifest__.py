# -*- coding: utf-8 -*-
#
#################################################################################
# Author      : Weblytic Labs Pvt. Ltd. (<https://store.weblyticlabs.com/>)
# Copyright(c): 2023-Present Weblytic Labs Pvt. Ltd.
# All Rights Reserved.
#
#
# This program is copyright property of the author mentioned above.
# You can`t redistribute it and/or modify it.
##################################################################################

{
    'name': 'CSV Tax Report',
    'version': '17.0.1.0.0',
    'summary': """CSV Tax Report""",
    'description': """CSV Tax Report""",
    'category': 'Accounting',
    'author': 'Weblytic Labs',
    'company': 'Weblytic Labs',
    'website': "https://store.weblyticlabs.com",
    'depends': ['base', 'web', 'website', 'account', 'website_sale', 'sale_management'],
    'license': 'OPL-1',
    'installable': True,
    'auto_install': False,
    'application': True,
    'data': [
        'security/ir.model.access.csv',
        'views/account_menuitem.xml',
        'views/res_config_settings_view.xml',
        'wizard/csv_tax_report_wizard.xml',
        'data/cron_invoice_export_email.xml',
        'data/invoice_csv_tax_report_mail_template.xml',
    ],
}
